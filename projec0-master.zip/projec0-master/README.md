This is yatinkumar Patel - Project 0

Deatils are below 

=> there are five different html file in this project.

1. index.html

    => in this file there are all other page hyperlink with unorderlist and one image which is support in all device.
    
2. alert.html 

    => in this file css call from bootstrap coponent.
    
3. gird.html

    => in this file css call from boostrap as well as my own css for flex box.
    
4. inhertance.html 

    => this file for inheritance example.

5. table.html

    => in this file table as well as nesting scss and one variable use in scss in tabel.scss
    
    
in this project one Main.css file with different css classes, media query and call class with id example.

there is two scss file for nesting.scss and table.scss.